/*
 * storage/pogls_delta_world_b.h — World B Storage Bridge
 * ═══════════════════════════════════════════════════════
 *
 * Thin forwarding layer: storage/ → core_c/
 * Rule: NEVER define types here — use core_c types exclusively.
 * Only thin inline wrappers permitted (no logic duplication).
 *
 * Architecture (Option A safe):
 *   core_c/   = ground truth (never touch)
 *   storage/  = #include core_c + forward-only inline bridge
 *   federation.h uses storage/ types (which ARE core_c types)
 */

#ifndef STORAGE_POGLS_DELTA_WORLD_B_H
#define STORAGE_POGLS_DELTA_WORLD_B_H

/* ── Ground truth: all types come from here ─────────────────────────── */
#include "../core_c/pogls_delta_world_b.h"

/* core_c/ provides:
 *   Delta_Context, Delta_ContextB, Delta_ContextAB
 *   Delta_DualMerkleRecord, Delta_DualRecovery
 *   Delta_RecoveryResult (CLEAN/TORN/NEW/ERROR)
 *   delta_ab_open(), delta_ab_commit(), delta_ab_recover(), delta_ab_close()
 *   delta_b_open(), delta_b_append(), delta_b_audit(), delta_b_close()
 *   delta_b_merkle_compute()
 *   DELTA_MAGIC = 0x504C4400 ("PLD\0")
 *   DELTA_MAX_PAYLOAD = 224
 *   LANE_COUNT = 4, LANE_B_COUNT = 4, LANE_TOTAL = 8
 */

/* ══════════════════════════════════════════════════════════════════════
 * THIN INLINE BRIDGE — forward-only, no new logic
 * ══════════════════════════════════════════════════════════════════════ */

/*
 * storage_delta_ab_open — thin forward to core_c
 * Creates .pogls/<vault>/world_b/ subdir if needed.
 */
static inline int storage_delta_ab_open(Delta_ContextAB *ctx,
                                         const char      *vault_path)
{
    return delta_ab_open(ctx, vault_path);
}

/*
 * storage_delta_ab_close — thin forward to core_c
 */
static inline int storage_delta_ab_close(Delta_ContextAB *ctx)
{
    return delta_ab_close(ctx);
}

/*
 * storage_delta_ab_append — route write to correct world lane PAIR
 *
 * Audit invariant: lane_X.seq == lane_nX.seq (pairs must stay equal)
 * Every write must go to BOTH lanes of its pair simultaneously.
 *
 * Pair mapping (logical_lane % 2):
 *   0 → X  pair: LANE_X  (0) + LANE_NX (1)   [World A]
 *             or  LANE_B_X(4) + LANE_B_NX(5)  [World B]
 *   1 → Y  pair: LANE_Y  (2) + LANE_NY  (3)   [World A]
 *             or  LANE_B_Y(6) + LANE_B_NY (7)  [World B]
 */
static inline int storage_delta_ab_append(Delta_ContextAB *ctx,
                                           int             world,
                                           uint32_t        logical_lane,
                                           uint64_t        addr,
                                           const void     *data,
                                           uint32_t        size)
{
    if (!ctx) return -1;
    int r0, r1;
    if (world == 0) {
        /* X pair (even logical) or Y pair (odd logical) */
        uint8_t lane_p = (logical_lane % 2u == 0u) ? LANE_X  : LANE_Y;
        uint8_t lane_n = (logical_lane % 2u == 0u) ? LANE_NX : LANE_NY;
        r0 = delta_append(&ctx->a, lane_p, addr, data, size);
        r1 = delta_append(&ctx->a, lane_n, addr, data, size);
    } else {
        uint8_t lane_p = (logical_lane % 2u == 0u) ? LANE_B_X  : LANE_B_Y;
        uint8_t lane_n = (logical_lane % 2u == 0u) ? LANE_B_NX : LANE_B_NY;
        r0 = delta_b_append(&ctx->b, lane_p, addr, data, size);
        r1 = delta_b_append(&ctx->b, lane_n, addr, data, size);
    }
    return (r0 == 0 && r1 == 0) ? 0 : -1;
}


/*
 * storage_delta_ab_recover — thin forward to core_c
 * Returns Delta_DualRecovery {world_a, world_b} each CLEAN/TORN/NEW/ERROR
 */
static inline Delta_DualRecovery storage_delta_ab_recover(const char *vault_path)
{
    return delta_ab_recover(vault_path);
}

/*
 * storage_delta_ab_commit — thin forward to core_c
 * Runs 9-step atomic dual Merkle commit protocol.
 */
static inline int storage_delta_ab_commit(Delta_ContextAB *ctx)
{
    return delta_ab_commit(ctx);
}

#endif /* STORAGE_POGLS_DELTA_WORLD_B_H */
