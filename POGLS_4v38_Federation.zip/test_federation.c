/*
 * test_federation.c — POGLS Federation Layer Test Suite
 * ══════════════════════════════════════════════════════
 *
 * FED01-FED05  fed_gate: PASS / GHOST / DROP conditions
 * FED06-FED08  BackpressureCtx: HWM throttle, resume, pop
 * FED09-FED11  ShadowSnapshot: init, commit, double-buffer swap
 * FED12-FED15  EarlyMerkle: update, reduce, tile hash consistency
 * FED16-FED20  fed_write full path: gate + BP + merkle + write
 * FED21-FED24  fed_commit: dual merkle A+B, atomic swap
 * FED25-FED27  fed_recover: clean path
 * FED28-FED30  Stress: 1000 writes, no overflow, determinism
 */
#include "storage/pogls_delta_world_b.h"
#include "pogls_federation.h"
#include <stdio.h>
#include <string.h>

static int _pass = 0, _fail = 0;
#define PASS(n)         do { printf("  \xe2\x9c\x85 %-48s PASS\n", n); _pass++; } while(0)
#define FAIL(n, ...)    do { printf("  \xe2\x9d\x8c %-48s FAIL -- ", n); printf(__VA_ARGS__); printf("\n"); _fail++; } while(0)
#define CHECK(n,c,...)  do { if(c) PASS(n); else FAIL(n,__VA_ARGS__); } while(0)
#define SECTION(s)      printf("\n-- %s --\n", s)

/* helper: build a packed GPU cell — V38 lane audit compliant
 *
 * V38 gate audit: hil = packed>>16, lane = (packed>>20)&0x3F
 *   invariant: (hil % 54) == lane
 *
 * Bit layout: [31:26]=upper6, [25:20]=lane, [19:16]=lower4, [0]=iso
 *   hil = upper6<<10 | lane<<4 | lower4
 *   hil % 54 must == lane
 *
 * Pre-computed base values (upper6+lower4) for all 54 lanes.
 */
static const uint32_t fed_packed_base[54] = {
    0x00000000u,  /* lane=0  */ 0x20110000u,  /* lane=1  */
    0x3c200000u,  /* lane=2  */ 0x00390000u,  /* lane=3  */
    0x0c400000u,  /* lane=4  */ 0x2c510000u,  /* lane=5  */
    0x48600000u,  /* lane=6  */ 0x00730000u,  /* lane=7  */
    0x18800000u,  /* lane=8  */ 0x38910000u,  /* lane=9  */
    0x00ac0000u,  /* lane=10 */ 0x08b10000u,  /* lane=11 */
    0x24c00000u,  /* lane=12 */ 0x44d10000u,  /* lane=13 */
    0x00e60000u,  /* lane=14 */ 0x14f10000u,  /* lane=15 */
    0x31000000u,  /* lane=16 */ 0x011f0000u,  /* lane=17 */
    0x01200000u,  /* lane=18 */ 0x21310000u,  /* lane=19 */
    0x3d400000u,  /* lane=20 */ 0x01590000u,  /* lane=21 */
    0x0d600000u,  /* lane=22 */ 0x2d710000u,  /* lane=23 */
    0x49800000u,  /* lane=24 */ 0x01930000u,  /* lane=25 */
    0x19a00000u,  /* lane=26 */ 0x39b10000u,  /* lane=27 */
    0x01cc0000u,  /* lane=28 */ 0x09d10000u,  /* lane=29 */
    0x25e00000u,  /* lane=30 */ 0x45f10000u,  /* lane=31 */
    0x02060000u,  /* lane=32 */ 0x16110000u,  /* lane=33 */
    0x32200000u,  /* lane=34 */ 0x023f0000u,  /* lane=35 */
    0x02400000u,  /* lane=36 */ 0x22510000u,  /* lane=37 */
    0x3e600000u,  /* lane=38 */ 0x02790000u,  /* lane=39 */
    0x0e800000u,  /* lane=40 */ 0x2e910000u,  /* lane=41 */
    0x4aa00000u,  /* lane=42 */ 0x02b30000u,  /* lane=43 */
    0x1ac00000u,  /* lane=44 */ 0x3ad10000u,  /* lane=45 */
    0x02ec0000u,  /* lane=46 */ 0x0af10000u,  /* lane=47 */
    0x27000000u,  /* lane=48 */ 0x47110000u,  /* lane=49 */
    0x03260000u,  /* lane=50 */ 0x17310000u,  /* lane=51 */
    0x33400000u,  /* lane=52 */ 0x035f0000u,  /* lane=53 */
};

static uint32_t make_packed(uint8_t lane, uint8_t iso)
{
    uint32_t l = (uint32_t)(lane % 54u);   /* clamp to valid range */
    return fed_packed_base[l] | (iso & 1u);
}

/* ── FED01-FED05  Gate ────────────────────────────────────────────── */
static void test_gate(void)
{
    SECTION("FED01-FED05  Pre-commit Gate");
    GateStats gs = {0};

    /* FED01: iso=0, valid lane, mature → PASS */
    uint32_t p1 = make_packed(5, 0);
    GateResult r1 = fed_gate(p1, 100, &gs);
    CHECK("FED01 iso=0 mature → GATE_PASS", r1 == GATE_PASS,
          "got=%d", r1);

    /* FED02: iso=1 → DROP */
    uint32_t p2 = make_packed(5, 1);
    GateResult r2 = fed_gate(p2, 100, &gs);
    CHECK("FED02 iso=1 → GATE_DROP", r2 == GATE_DROP,
          "got=%d", r2);

    /* FED03: op_count < GHOST_STREAK_MAX → GHOST (warm-up) */
    uint32_t p3 = make_packed(3, 0);
    GateResult r3 = fed_gate(p3, 2, &gs);
    CHECK("FED03 op_count<8 → GATE_GHOST", r3 == GATE_GHOST,
          "got=%d", r3);

    /* FED04: lane=63 (max valid) → PASS when mature */
    uint32_t p4 = make_packed(53, 0);
    GateResult r4 = fed_gate(p4, 999, &gs);
    CHECK("FED04 lane=53 mature → GATE_PASS", r4 == GATE_PASS,
          "got=%d", r4);

    /* FED05: stats counters updated */
    CHECK("FED05 gate stats passed >= 2", gs.passed >= 2,
          "passed=%llu", (unsigned long long)gs.passed);
    CHECK("FED05 gate stats dropped >= 1", gs.dropped >= 1,
          "dropped=%llu", (unsigned long long)gs.dropped);
}

/* ── FED06-FED08  Backpressure ───────────────────────────────────── */
static void test_backpressure(void)
{
    SECTION("FED06-FED08  Backpressure");
    BackpressureCtx bp;
    bp_init(&bp);

    /* FED06: fresh BP → bp_check returns 0 (no throttle) */
    CHECK("FED06 fresh BP no throttle", bp_check(&bp) == 0,
          "depth=%u", bp.queue_depth);

    /* FED07: fill to HWM → bp_check returns 1 */
    for (uint32_t i = 0; i < FED_QUEUE_HWM + 1; i++)
        bp_push(&bp);
    CHECK("FED07 depth > HWM → bp_check=1", bp_check(&bp) == 1,
          "depth=%u hwm=%u", bp.queue_depth, FED_QUEUE_HWM);

    /* FED08: drain below LWM → bp_check returns 0 */
    while (bp.queue_depth > FED_QUEUE_LWM / 2)
        bp_pop(&bp);
    CHECK("FED08 drain to LWM/2 → bp_check=0", bp_check(&bp) == 0,
          "depth=%u lwm=%u", bp.queue_depth, FED_QUEUE_LWM);
}

/* ── FED09-FED11  ShadowSnapshot ────────────────────────────────── */
static void test_shadow_snapshot(void)
{
    SECTION("FED09-FED11  Shadow Snapshot");
    ShadowSnapshot ss;

    /* FED09: ss_init with temp vault */
    int r = ss_init(&ss, "/tmp/fed_test_vault");
    CHECK("FED09 ss_init returns 0", r == 0, "r=%d", r);
    CHECK("FED09 active starts at 0", ss.active == 0, "active=%u", ss.active);

    /* FED10: ss_commit swaps active buffer */
    int rc = ss_commit(&ss);
    CHECK("FED10 ss_commit returns 0", rc == 0, "rc=%d", rc);
    CHECK("FED10 active swapped to 1", ss.active == 1, "active=%u", ss.active);

    /* FED11: second commit swaps back to 0 */
    ss_commit(&ss);
    CHECK("FED11 second commit active=0", ss.active == 0, "active=%u", ss.active);

    ss_close(&ss);
}

/* ── FED12-FED15  EarlyMerkle ────────────────────────────────────── */
static void test_early_merkle(void)
{
    SECTION("FED12-FED15  Early Merkle");
    EarlyMerkle em;
    em_init(&em);

    /* FED12: fresh merkle → all tile hashes zero */
    int all_zero = 1;
    for (uint32_t i = 0; i < FED_TILE_COUNT; i++)
        if (em.tile_hash[i] != 0) { all_zero = 0; break; }
    CHECK("FED12 fresh tiles all zero", all_zero, "tile[0]=%016llx",
          (unsigned long long)em.tile_hash[0]);

    /* FED13: em_update changes tile hash */
    uint8_t buf[8] = {0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08};
    em_update(&em, 5, buf, 8);
    CHECK("FED13 em_update changes tile[5]", em.tile_hash[5] != 0,
          "tile[5]=%016llx", (unsigned long long)em.tile_hash[5]);

    /* FED14: em_update is deterministic */
    EarlyMerkle em2;
    em_init(&em2);
    em_update(&em2, 5, buf, 8);
    CHECK("FED14 em_update deterministic", em.tile_hash[5] == em2.tile_hash[5],
          "a=%016llx b=%016llx",
          (unsigned long long)em.tile_hash[5],
          (unsigned long long)em2.tile_hash[5]);

    /* FED15: em_reduce sets root_valid=1 and root[] non-zero */
    em_reduce(&em);
    CHECK("FED15 em_reduce sets root_valid", em.root_valid == 1,
          "root_valid=%u", em.root_valid);
    int root_nonzero = 0;
    for (int i = 0; i < 32; i++) if (em.root[i] != 0) { root_nonzero = 1; break; }
    CHECK("FED15 em_reduce root[] non-zero", root_nonzero,
          "root all zero");
}

/* ── FED16-FED20  fed_write ──────────────────────────────────────── */
static void test_fed_write(void)
{
    SECTION("FED16-FED20  fed_write full path");
    FederationCtx f;
    int r = fed_init(&f, "/tmp/fed_test_write");
    CHECK("FED16 fed_init returns 0", r == 0, "r=%d", r);

    /* FED17: PASS write increments op_count */
    uint32_t p = make_packed(5, 0);
    uint64_t op_before = f.op_count;
    GateResult gr = fed_write(&f, p, 0x100ULL, 0xDEADBEEFULL);
    /* first write: op_count < GHOST_STREAK_MAX → GHOST */
    int wrote = (gr == GATE_PASS || gr == GATE_GHOST);
    CHECK("FED17 fed_write returns PASS or GHOST", wrote, "gr=%d", gr);

    /* FED18: iso=1 → DROP, op_count unchanged */
    uint32_t p_iso = make_packed(5, 1);
    uint64_t op_mid = f.op_count;
    fed_write(&f, p_iso, 0x200ULL, 0xCAFEULL);
    CHECK("FED18 iso=1 DROP does not increment op_count",
          f.op_count == op_mid, "op=%llu expected=%llu",
          (unsigned long long)f.op_count, (unsigned long long)op_mid);

    /* FED19: 100 mature writes succeed */
    int ok = 1;
    for (uint32_t i = 0; i < 100; i++) {
        GateResult g = fed_write(&f, make_packed(i%54, 0),
                                 (uint64_t)i * 1000ULL,
                                 (uint64_t)i * 0x1234ULL);
        if (g == GATE_DROP) { ok = 0; break; }
    }
    CHECK("FED19 100 mature writes no DROP", ok, "failed at some write");

    /* FED20: gate stats consistent */
    CHECK("FED20 gate.passed + gate.ghosted + gate.dropped > 0",
          f.gate.passed + f.gate.ghosted + f.gate.dropped > 0,
          "all zero?");

    fed_close(&f);
}

/* ── FED21-FED24  fed_commit ─────────────────────────────────────── */
static void test_fed_commit(void)
{
    SECTION("FED21-FED24  fed_commit dual Merkle");
    FederationCtx f;
    fed_init(&f, "/tmp/fed_test_commit");

    /* prime with 50 mature writes */
    for (uint32_t i = 0; i < 50; i++)
        fed_write(&f, make_packed(i % 54, 0),
                  (uint64_t)i * 500ULL, (uint64_t)i);

    /* FED21: fed_commit returns 0 */
    int rc = fed_commit(&f);
    CHECK("FED21 fed_commit returns 0", rc == 0, "rc=%d", rc);

    /* FED22: shadow snapshot swapped after commit */
    uint32_t active_after = f.ss.active;
    CHECK("FED22 active buffer swapped", active_after == 1,
          "active=%u", active_after);

    /* FED23: both EarlyMerkle em_a + em_b reset after commit */
    int tiles_reset = 1;
    for (uint32_t i = 0; i < FED_TILE_COUNT; i++) {
        if (f.em_a.tile_hash[i] != 0) { tiles_reset = 0; break; }
        if (f.em_b.tile_hash[i] != 0) { tiles_reset = 0; break; }
    }
    CHECK("FED23 em_a+em_b tiles reset after commit", tiles_reset,
          "em_a[0]=%016llx em_b[0]=%016llx",
          (unsigned long long)f.em_a.tile_hash[0],
          (unsigned long long)f.em_b.tile_hash[0]);

    /* FED24: second commit also succeeds */
    for (uint32_t i = 0; i < 20; i++)
        fed_write(&f, make_packed(i % 54, 0), (uint64_t)i, (uint64_t)i);
    int rc2 = fed_commit(&f);
    CHECK("FED24 second fed_commit returns 0", rc2 == 0, "rc=%d", rc2);

    fed_close(&f);
}

/* ── FED25-FED27  Recovery ───────────────────────────────────────── */
static void test_recovery(void)
{
    SECTION("FED25-FED27  Recovery");

    /* FED25: fed_recover returns CLEAN for fresh path */
    Delta_DualRecovery dr = fed_recover("/tmp/fed_test_recovery");
    CHECK("FED25 fed_recover world_a clean or new",
          dr.world_a == DELTA_RECOVERY_CLEAN || dr.world_a == DELTA_RECOVERY_NEW,
          "world_a=%d", dr.world_a);
    CHECK("FED26 fed_recover world_b clean or new",
          dr.world_b == DELTA_RECOVERY_CLEAN || dr.world_b == DELTA_RECOVERY_NEW,
          "world_b=%d", dr.world_b);

    /* FED27: NULL vault → handled gracefully */
    FederationCtx f;
    int r = fed_init(&f, NULL);
    CHECK("FED27 fed_init NULL vault returns -1", r == -1, "r=%d", r);
}

/* ── FED28-FED30  Stress ────────────────────────────────────────── */
static void test_stress(void)
{
    SECTION("FED28-FED30  Stress + Determinism");

    /* FED28: 1000 writes, backpressure never permanently stuck */
    FederationCtx f;
    fed_init(&f, "/tmp/fed_test_stress");
    uint64_t drops = 0;
    for (uint32_t i = 0; i < 1000; i++) {
        GateResult g = fed_write(&f, make_packed(i % 54, 0),
                                 (uint64_t)i * 777ULL, (uint64_t)i);
        if (g == GATE_DROP) drops++;
        /* drain every 128 to simulate V4 consuming */
        if (i % 128 == 127) fed_drain(&f, 256);
    }
    CHECK("FED28 1000 writes drops only from iso (0 here)", drops == 0,
          "drops=%llu", (unsigned long long)drops);

    /* FED29: commit after bulk write succeeds */
    int rc = fed_commit(&f);
    CHECK("FED29 bulk commit returns 0", rc == 0, "rc=%d", rc);

    /* FED30: determinism — same sequence → same combined_root */
    FederationCtx fa, fb;
    fed_init(&fa, "/tmp/fed_test_det_a");
    fed_init(&fb, "/tmp/fed_test_det_b");
    for (uint32_t i = 0; i < 50; i++) {
        uint32_t p = make_packed(i % 54, 0);
        fed_write(&fa, p, (uint64_t)i, (uint64_t)i * 0xABCDULL);
        fed_write(&fb, p, (uint64_t)i, (uint64_t)i * 0xABCDULL);
    }
    /* force merkle reduce on both worlds, compare roots */
    fed_update_roots(&fa);
    fed_update_roots(&fb);
    CHECK("FED30 deterministic root_a[]",
          memcmp(fa.root_a, fb.root_a, 32) == 0,
          "root_a mismatch");
    CHECK("FED30 deterministic root_b[]",
          memcmp(fa.root_b, fb.root_b, 32) == 0,
          "root_b mismatch");
    fed_close(&fa);
    fed_close(&fb);
    fed_close(&f);
}


/* ── FED31-FED42  World B Routing ────────────────────────────────── */
static void test_world_routing(void)
{
    SECTION("FED31-FED42  World B Routing (Switch Gate)");

    /* FED31: same (addr, step) → same world every time */
    int w1 = fed_switch_gate(0xDEADBEEF12345678ULL, 42);
    int w2 = fed_switch_gate(0xDEADBEEF12345678ULL, 42);
    CHECK("FED31 switch_gate deterministic", w1 == w2,
          "w1=%d w2=%d", w1, w2);

    /* FED32: switch_gate returns 0 or 1 only */
    int valid = 1;
    for (uint32_t s = 0; s < 1000; s++) {
        int w = fed_switch_gate((uint64_t)s * 0x123456789ABCULL, s);
        if (w != 0 && w != 1) { valid = 0; break; }
    }
    CHECK("FED32 switch_gate returns 0 or 1 only", valid, "invalid world");

    /* FED33: 10000 inputs → both worlds get writes (50/50 split) */
    uint64_t cnt_a = 0, cnt_b = 0;
    for (uint32_t s = 0; s < 10000; s++) {
        int w = fed_switch_gate((uint64_t)s * 0x9E3779B97F4A7C15ULL, s);
        if (w == 0) cnt_a++; else cnt_b++;
    }
    /* expect 40-60% range for fair split */
    int fair = (cnt_a >= 4000 && cnt_a <= 6000);
    CHECK("FED33 switch_gate 40-60%% split over 10000", fair,
          "A=%llu B=%llu", (unsigned long long)cnt_a, (unsigned long long)cnt_b);

    /* FED34: different (addr,step) pairs → routes to both worlds
     * Use step=a to match real usage (op_count increments with writes).
     * step=0 fixed with a<2^31 always gives world=0 (not a useful test). */
    int found_a = 0, found_b = 0;
    for (uint32_t s = 0; s < 1000; s++) {
        int w = fed_switch_gate((uint64_t)s * 0xCAFEBABEULL, s);
        if (w == 0) found_a = 1;
        if (w == 1) found_b = 1;
        if (found_a && found_b) break;
    }
    CHECK("FED34 routing reaches World A", found_a, "never routed to A");
    CHECK("FED34 routing reaches World B", found_b, "never routed to B");

    /* FED35: lane audit still holds after routing */
    /* make_packed(lane) satisfies fed_lane_ok for all 54 lanes */
    int audit_ok = 1;
    for (uint8_t lane = 0; lane < 54; lane++) {
        uint32_t p = make_packed(lane, 0);
        uint32_t hil = p >> 16;
        uint32_t ext_lane = (p >> 20) & 0x3Fu;
        if (!fed_lane_ok(hil, ext_lane)) { audit_ok = 0; break; }
    }
    CHECK("FED35 all 54 lanes pass audit after routing", audit_ok,
          "lane audit broken");

    /* FED36: writes to A do NOT affect em_b tiles */
    FederationCtx f;
    fed_init(&f, "/tmp/fed_test_routing");
    /* warm up past ghost window */
    for (int i = 0; i < 10; i++)
        fed_write(&f, make_packed(i % 54, 0), (uint64_t)i, (uint64_t)i);
    uint64_t b_before = 0;
    for (uint32_t i = 0; i < FED_TILE_COUNT; i++) b_before += f.em_b.tile_hash[i];
    /* write only to World A by forcing gate addr that routes to A */
    /* find an addr that goes to World A */
    uint64_t addr_a = 0;
    for (uint64_t a = 0; a < 10000; a++) {
        if (fed_switch_gate(a, (uint32_t)(f.op_count + 1)) == FED_WORLD_A) {
            addr_a = a; break;
        }
    }
    uint64_t b_check = 0;
    for (uint32_t i = 0; i < FED_TILE_COUNT; i++) b_check += f.em_b.tile_hash[i];
    /* em_b should have changed only if some writes went to B during warm-up */
    /* the invariant: writes[0] + writes[1] == op_count */
    CHECK("FED36 writes[A] + writes[B] == op_count",
          f.writes[0] + f.writes[1] == f.op_count,
          "writes_A=%llu writes_B=%llu op=%llu",
          (unsigned long long)f.writes[0],
          (unsigned long long)f.writes[1],
          (unsigned long long)f.op_count);
    fed_close(&f);

    /* FED37: 1000 writes → both worlds receive writes */
    FederationCtx f2;
    fed_init(&f2, "/tmp/fed_test_routing2");
    for (uint32_t i = 0; i < 1000; i++)
        fed_write(&f2, make_packed(i % 54, 0),
                  (uint64_t)i * 0x123ABCULL, (uint64_t)i);
    CHECK("FED37 World A received writes", f2.writes[0] > 0,
          "writes_A=%llu", (unsigned long long)f2.writes[0]);
    CHECK("FED37 World B received writes", f2.writes[1] > 0,
          "writes_B=%llu", (unsigned long long)f2.writes[1]);
    fed_close(&f2);

    /* FED38: root_a != root_b after mixed writes (worlds diverge) */
    FederationCtx f3;
    fed_init(&f3, "/tmp/fed_test_routing3");
    for (uint32_t i = 0; i < 200; i++)
        fed_write(&f3, make_packed(i % 54, 0),
                  (uint64_t)i * 0xABCDEF01ULL, (uint64_t)i * 7ULL);
    fed_update_roots(&f3);
    /* roots should differ because different data went to each world */
    int roots_differ = (memcmp(f3.root_a, f3.root_b, 32) != 0);
    CHECK("FED38 root_a != root_b after mixed writes", roots_differ,
          "roots identical — world isolation broken");
    fed_close(&f3);

    /* FED39: same sequence → same root_a, same root_b (full determinism) */
    FederationCtx fc, fd;
    fed_init(&fc, "/tmp/fed_test_det_c");
    fed_init(&fd, "/tmp/fed_test_det_d");
    for (uint32_t i = 0; i < 100; i++) {
        uint32_t p = make_packed(i % 54, 0);
        uint64_t a = (uint64_t)i * 0xFEDCBA98ULL;
        uint64_t d = (uint64_t)i * 0x11223344ULL;
        fed_write(&fc, p, a, d);
        fed_write(&fd, p, a, d);
    }
    fed_update_roots(&fc);
    fed_update_roots(&fd);
    CHECK("FED39 deterministic root_a",
          memcmp(fc.root_a, fd.root_a, 32) == 0, "root_a mismatch");
    CHECK("FED39 deterministic root_b",
          memcmp(fc.root_b, fd.root_b, 32) == 0, "root_b mismatch");
    CHECK("FED39 writes[A] match",
          fc.writes[0] == fd.writes[0],
          "A: %llu vs %llu",
          (unsigned long long)fc.writes[0],
          (unsigned long long)fd.writes[0]);
    fed_close(&fc);
    fed_close(&fd);

    /* FED40: commit clears both em_a and em_b */
    FederationCtx f4;
    fed_init(&f4, "/tmp/fed_test_routing4");
    for (uint32_t i = 0; i < 50; i++)
        fed_write(&f4, make_packed(i % 54, 0), (uint64_t)i, (uint64_t)i);
    fed_commit(&f4);
    int both_clear = 1;
    for (uint32_t i = 0; i < FED_TILE_COUNT; i++) {
        if (f4.em_a.tile_hash[i] != 0 || f4.em_b.tile_hash[i] != 0)
            { both_clear = 0; break; }
    }
    CHECK("FED40 commit clears em_a + em_b tiles", both_clear,
          "tiles not cleared");
    fed_close(&f4);

    /* FED41: root_a valid after fed_update_roots */
    FederationCtx f5;
    fed_init(&f5, "/tmp/fed_test_routing5");
    for (uint32_t i = 0; i < 20; i++)
        fed_write(&f5, make_packed(i % 54, 0), (uint64_t)i, (uint64_t)i);
    fed_update_roots(&f5);
    CHECK("FED41 root_a valid after fed_update_roots",
          f5.em_a.root_valid == 1, "root_valid_a=%u", f5.em_a.root_valid);
    CHECK("FED41 root_b valid after fed_update_roots",
          f5.em_b.root_valid == 1, "root_valid_b=%u", f5.em_b.root_valid);
    fed_close(&f5);

    /* FED42: fed_lane_ok matches gate audit for all 54 lanes */
    int lane_audit_ok = 1;
    for (uint8_t lane = 0; lane < 54; lane++) {
        uint32_t p   = make_packed(lane, 0);
        uint32_t hil = p >> 16;
        uint32_t ext = (p >> 20) & 0x3Fu;
        if (!fed_lane_ok(hil, ext)) { lane_audit_ok = 0; break; }
        /* cross-check: hil % 54 == ext */
        if ((hil % 54u) != ext) { lane_audit_ok = 0; break; }
    }
    CHECK("FED42 fed_lane_ok passes all 54 make_packed lanes",
          lane_audit_ok, "lane audit broken");
}

/* ── FED43-FED50  Disk Append (real delta_ab_append) ───────────────── */
static void test_disk_append(void)
{
    SECTION("FED43-FED50  Disk Append (World A + B lanes)");

    /* FED43: fed_init opens disk contexts cleanly */
    FederationCtx f;
    int r = fed_init(&f, "/tmp/fed_disk_test");
    CHECK("FED43 fed_init opens A+B disk contexts", r == 0, "r=%d", r);
    CHECK("FED43 dab.a is_open", f.dab.a.is_open, "a not open");
    CHECK("FED43 dab.b is_open", f.dab.b.is_open, "b not open");

    /* FED44: first write goes to disk (lane seq advances) */
    uint64_t seq_a_before = f.dab.a.lane_seq[0] + f.dab.a.lane_seq[1]
                          + f.dab.a.lane_seq[2] + f.dab.a.lane_seq[3];
    uint64_t seq_b_before = f.dab.b.lane_seq[0] + f.dab.b.lane_seq[1]
                          + f.dab.b.lane_seq[2] + f.dab.b.lane_seq[3];
    /* warm up + write 50 times */
    for (uint32_t i = 0; i < 50; i++)
        fed_write(&f, make_packed(i % 54, 0),
                  (uint64_t)i * 0x11111111ULL, (uint64_t)i);
    uint64_t seq_a_after = f.dab.a.lane_seq[0] + f.dab.a.lane_seq[1]
                         + f.dab.a.lane_seq[2] + f.dab.a.lane_seq[3];
    uint64_t seq_b_after = f.dab.b.lane_seq[0] + f.dab.b.lane_seq[1]
                         + f.dab.b.lane_seq[2] + f.dab.b.lane_seq[3];
    CHECK("FED44 World A lane seqs advanced after writes",
          seq_a_after > seq_a_before,
          "seq_a before=%llu after=%llu",
          (unsigned long long)seq_a_before,
          (unsigned long long)seq_a_after);
    CHECK("FED44 World B lane seqs advanced after writes",
          seq_b_after > seq_b_before,
          "seq_b before=%llu after=%llu",
          (unsigned long long)seq_b_before,
          (unsigned long long)seq_b_after);

    /* FED45: total seq advances == op_count (every non-DROP write hit disk) */
    uint64_t total_seq = seq_a_after + seq_b_after;
    /* Each non-DROP write advances 2 lane seqs (paired write: X + nX or Y + nY)
     * so total_seq == op_count * 2 */
    CHECK("FED45 total lane seq advances == op_count*2 (paired writes)",
          total_seq == f.op_count * 2u,
          "total_seq=%llu op_count=%llu (expected %llu)",
          (unsigned long long)total_seq,
          (unsigned long long)f.op_count,
          (unsigned long long)(f.op_count * 2u));

    /* FED46: commit succeeds with real disk data */
    int rc = fed_commit(&f);
    CHECK("FED46 fed_commit returns 0 with real disk data", rc == 0,
          "rc=%d", rc);

    /* FED47: after commit, lane seqs preserved (not reset) */
    uint64_t seq_a_post = f.dab.a.lane_seq[0] + f.dab.a.lane_seq[1]
                        + f.dab.a.lane_seq[2] + f.dab.a.lane_seq[3];
    CHECK("FED47 lane seqs preserved across commit",
          seq_a_post == seq_a_after,
          "seq changed: before=%llu after=%llu",
          (unsigned long long)seq_a_after,
          (unsigned long long)seq_a_post);

    fed_close(&f);

    /* FED48: World A writes only go to dab.a lanes */
    FederationCtx fa;
    fed_init(&fa, "/tmp/fed_disk_world_a");
    /* find 20 addrs that route to World A */
    uint32_t got_a = 0;
    for (uint32_t i = 0; i < 10000 && got_a < 20; i++) {
        if (fed_switch_gate((uint64_t)i * 0xABCDULL,
                            (uint32_t)fa.op_count) == FED_WORLD_A) {
            fed_write(&fa, make_packed(i % 54, 0),
                      (uint64_t)i * 0xABCDULL, (uint64_t)i);
            got_a++;
        }
    }
    /* seq_a must have advanced by exactly got_a */
    uint64_t sa = fa.dab.a.lane_seq[0] + fa.dab.a.lane_seq[1]
                + fa.dab.a.lane_seq[2] + fa.dab.a.lane_seq[3];
    /* Each World A write → 2 lane seqs (paired: X+nX or Y+nY) */
    CHECK("FED48 World A lane seqs == writes_A * 2 (paired)",
          sa == fa.writes[0] * 2u,
          "sa=%llu writes_A=%llu (expected %llu)",
          (unsigned long long)sa,
          (unsigned long long)fa.writes[0],
          (unsigned long long)(fa.writes[0] * 2u));
    fed_close(&fa);

    /* FED49: World B writes only go to dab.b lanes */
    FederationCtx fb;
    fed_init(&fb, "/tmp/fed_disk_world_b");
    uint32_t got_b = 0;
    for (uint32_t i = 0; i < 10000 && got_b < 20; i++) {
        if (fed_switch_gate((uint64_t)i * 0xDEADULL,
                            (uint32_t)fb.op_count) == FED_WORLD_B) {
            fed_write(&fb, make_packed(i % 54, 0),
                      (uint64_t)i * 0xDEADULL, (uint64_t)i);
            got_b++;
        }
    }
    uint64_t sb = fb.dab.b.lane_seq[0] + fb.dab.b.lane_seq[1]
                + fb.dab.b.lane_seq[2] + fb.dab.b.lane_seq[3];
    /* Each World B write → 2 lane seqs (paired: bX+bnX or bY+bnY) */
    CHECK("FED49 World B lane seqs == writes_B * 2 (paired)",
          sb == fb.writes[1] * 2u,
          "sb=%llu writes_B=%llu (expected %llu)",
          (unsigned long long)sb,
          (unsigned long long)fb.writes[1],
          (unsigned long long)(fb.writes[1] * 2u));
    fed_close(&fb);

    /* FED50: iso=1 DROP → zero disk writes */
    FederationCtx fi;
    fed_init(&fi, "/tmp/fed_disk_iso");
    uint64_t sa_iso = fi.dab.a.lane_seq[0] + fi.dab.a.lane_seq[1]
                    + fi.dab.a.lane_seq[2] + fi.dab.a.lane_seq[3];
    uint64_t sb_iso = fi.dab.b.lane_seq[0] + fi.dab.b.lane_seq[1]
                    + fi.dab.b.lane_seq[2] + fi.dab.b.lane_seq[3];
    for (uint32_t i = 0; i < 100; i++)
        fed_write(&fi, make_packed(i % 54, 1), (uint64_t)i, (uint64_t)i);
    uint64_t sa_iso2 = fi.dab.a.lane_seq[0] + fi.dab.a.lane_seq[1]
                     + fi.dab.a.lane_seq[2] + fi.dab.a.lane_seq[3];
    uint64_t sb_iso2 = fi.dab.b.lane_seq[0] + fi.dab.b.lane_seq[1]
                     + fi.dab.b.lane_seq[2] + fi.dab.b.lane_seq[3];
    CHECK("FED50 iso=1 DROP produces zero disk writes (World A)",
          sa_iso2 == sa_iso, "seq advanced unexpectedly");
    CHECK("FED50 iso=1 DROP produces zero disk writes (World B)",
          sb_iso2 == sb_iso, "seq advanced unexpectedly");
    fed_close(&fi);
}

/* ── main ─────────────────────────────────────────────────────────── */
int main(void)
{
    printf("\xe2\x95\x94\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x97\n");
    printf("\xe2\x95\x91  POGLS Federation Layer Test Suite                  \xe2\x95\x91\n");
    printf("\xe2\x95\x9a\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x9d\n");

    test_gate();
    test_backpressure();
    test_shadow_snapshot();
    test_early_merkle();
    test_fed_write();
    test_fed_commit();
    test_recovery();
    test_stress();
    test_world_routing();
    test_disk_append();

    int total = _pass + _fail;
    printf("\n\xe2\x95\x94\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x97\n");
    printf("\xe2\x95\x91  RESULT: %d/%d PASS  %s%-5s                            \xe2\x95\x91\n",
           _pass, total,
           _fail == 0 ? "\xe2\x9c\x85 " : "\xe2\x9d\x8c ",
           _fail == 0 ? "CLEAN" : "FAIL");
    printf("\xe2\x95\x9a\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x9d\n");
    return _fail == 0 ? 0 : 1;
}
