/*
 * pogls_federation.h — POGLS V4x Federation Bridge Layer
 * ═══════════════════════════════════════════════════════
 *
 * GPU (POGLS38) → Pre-Gate → Federation → V4 Shadow Snapshot → disk
 *
 * Architecture: Option A (safe)
 *   - All types from core_c/ (NEVER from compat layer)
 *   - storage/ layer for disk I/O (thin bridge only)
 *   - DELTA_MAGIC = 0x504C4400 ("PLD\0") — V38 wire format
 *   - DELTA_MAX_PAYLOAD = 224B — V38 block size
 *   - Lane audit invariant enforced: (hil % 54) == lane → or DROP
 *
 * V38 EarlyMerkle format:
 *   root[32]    — byte array (NOT combined_root uint64)
 *   root_valid  — 1 when em_reduce() has run
 */

#ifndef POGLS_FEDERATION_H
#define POGLS_FEDERATION_H

#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

/* Ground-truth types come from storage layer (which forwards core_c) */
#include "storage/pogls_delta_world_b.h"

/* ══════════════════════════════════════════════════════════════════════
 * DEBUG TOGGLE
 * ══════════════════════════════════════════════════════════════════════ */
#ifndef POGLS_USE_V38
#define POGLS_USE_V38  1   /* 1 = V38 lane audit + V38 Merkle format */
#endif

/* ══════════════════════════════════════════════════════════════════════
 * SECTION 1 — CONSTANTS
 * ══════════════════════════════════════════════════════════════════════ */

/* V38 lane audit: every packed cell must satisfy (hil % 54) == lane */
#define FED_LANE_MODULO     54u

/* EarlyMerkle tile count — matches V38 lane space */
#define FED_TILE_COUNT      54u

/* Ghost warm-up: first GHOST_STREAK_MAX ops are GHOST (not committed) */
#ifndef POGLS_GHOST_STREAK_MAX
#define POGLS_GHOST_STREAK_MAX  8u
#endif

/* Backpressure queue thresholds */
#define FED_QUEUE_HWM       256u   /* high-water mark → throttle */
#define FED_QUEUE_LWM       64u    /* low-water mark  → resume   */
#define FED_QUEUE_MAX       512u   /* hard max (ring wrap) */

/* Shadow snapshot double-buffer slots */
#define FED_SS_SLOTS        2u

/* ══════════════════════════════════════════════════════════════════════
 * SECTION 2 — PRE-COMMIT GATE
 *
 * GPU cell packing (V38 wire format):
 *   bit[25:20] = lane  (6 bits, 0..53 valid)
 *   bit[0]     = iso   (isolation flag)
 *   bit[31:16] = hil   (high-isolation level, used for lane audit)
 *
 * Gate logic:
 *   iso == 1         → DROP  (isolation bit set)
 *   op_count < 8     → GHOST (warm-up window)
 *   else             → PASS
 *
 * Lane audit (POGLS_USE_V38):
 *   hil = packed >> 16
 *   (hil % 54) != lane → DROP
 * ══════════════════════════════════════════════════════════════════════ */

typedef enum {
    GATE_PASS  = 0,
    GATE_GHOST = 1,
    GATE_DROP  = 2,
} GateResult;

typedef struct {
    uint64_t passed;
    uint64_t ghosted;
    uint64_t dropped;
} GateStats;

static inline GateResult fed_gate(uint32_t packed,
                                   uint64_t op_count,
                                   GateStats *gs)
{
    uint32_t lane = (packed >> 20) & 0x3Fu;
    uint32_t iso  = packed & 1u;

    /* iso=1 → always DROP */
    if (iso) {
        if (gs) gs->dropped++;
        return GATE_DROP;
    }

#if POGLS_USE_V38
    /* V38 lane audit: (hil % 54) must equal lane */
    uint32_t hil = packed >> 16;
    if ((hil % FED_LANE_MODULO) != lane) {
        if (gs) gs->dropped++;
        return GATE_DROP;
    }
#endif

    /* warm-up ghost window */
    if (op_count < POGLS_GHOST_STREAK_MAX) {
        if (gs) gs->ghosted++;
        return GATE_GHOST;
    }

    if (gs) gs->passed++;
    return GATE_PASS;
}

/* ══════════════════════════════════════════════════════════════════════
 * SECTION 3 — BACKPRESSURE CONTEXT
 * ══════════════════════════════════════════════════════════════════════ */

typedef struct {
    uint32_t queue_depth;
    uint32_t _pad;
} BackpressureCtx;

static inline void bp_init(BackpressureCtx *bp)
{
    if (!bp) return;
    bp->queue_depth = 0;
}

/* Returns 1 if throttling (depth > HWM), 0 otherwise */
static inline int bp_check(const BackpressureCtx *bp)
{
    if (!bp) return 0;
    return (bp->queue_depth > FED_QUEUE_HWM) ? 1 : 0;
}

static inline void bp_push(BackpressureCtx *bp)
{
    if (!bp) return;
    if (bp->queue_depth < FED_QUEUE_MAX)
        bp->queue_depth++;
}

static inline void bp_pop(BackpressureCtx *bp)
{
    if (!bp || bp->queue_depth == 0) return;
    bp->queue_depth--;
}

/* Drain up to n items from queue */
static inline uint32_t bp_drain(BackpressureCtx *bp, uint32_t n)
{
    if (!bp) return 0;
    uint32_t actual = (n < bp->queue_depth) ? n : bp->queue_depth;
    bp->queue_depth -= actual;
    return actual;
}

/* ══════════════════════════════════════════════════════════════════════
 * SECTION 4 — SHADOW SNAPSHOT (double-buffer)
 * ══════════════════════════════════════════════════════════════════════ */

typedef struct {
    char     vault[512];
    uint32_t active;     /* 0 or 1 */
    uint32_t epoch;
} ShadowSnapshot;

static inline int ss_init(ShadowSnapshot *ss, const char *vault_path)
{
    if (!ss) return -1;
    memset(ss, 0, sizeof(*ss));
    if (!vault_path) return -1;
    strncpy(ss->vault, vault_path, sizeof(ss->vault)-1);
    ss->active = 0;
    return 0;
}

static inline int ss_commit(ShadowSnapshot *ss)
{
    if (!ss) return -1;
    ss->active = (ss->active + 1u) % FED_SS_SLOTS;
    ss->epoch++;
    return 0;
}

static inline void ss_close(ShadowSnapshot *ss) { (void)ss; }

/* ══════════════════════════════════════════════════════════════════════
 * SECTION 5 — EARLY MERKLE (V38 format)
 *
 * V38 format: root[32] byte array + root_valid flag
 *   (NOT combined_root uint64 — that was V3/compat format)
 *
 * em_reduce() computes XOR-fold of all 54 tile_hashes → root[32]
 * combined_root = first 8 bytes of root[] (kept for legacy test compat)
 * ══════════════════════════════════════════════════════════════════════ */

typedef struct {
    uint64_t tile_hash[FED_TILE_COUNT];   /* per-tile running hash        */
    uint8_t  root[32];                    /* V38: byte array merkle root  */
    uint32_t root_valid;                  /* 1 after em_reduce()          */
    uint32_t _pad;
    uint64_t combined_root;               /* legacy: first 8 bytes root[] */
} EarlyMerkle;

static inline void em_init(EarlyMerkle *em)
{
    if (!em) return;
    memset(em, 0, sizeof(*em));
}

/* Mix data into tile[tile_id] using FNV-1a 64-bit */
static inline void em_update(EarlyMerkle *em, uint32_t tile_id,
                               const uint8_t *data, uint32_t len)
{
    if (!em || tile_id >= FED_TILE_COUNT || !data) return;
    uint64_t h = em->tile_hash[tile_id];
    if (h == 0) h = 14695981039346656037ULL;
    for (uint32_t i = 0; i < len; i++) {
        h ^= data[i];
        h *= 1099511628211ULL;
    }
    em->tile_hash[tile_id] = h;
    em->root_valid = 0;
}

/*
 * em_reduce — V38 Merkle root computation
 * XOR-fold 54 tiles × 8 bytes into 4 accumulators → root[32]
 */
static inline void em_reduce(EarlyMerkle *em)
{
    if (!em) return;

    uint64_t acc[4] = {
        14695981039346656037ULL,
        14695981039346656037ULL,
        14695981039346656037ULL,
        14695981039346656037ULL,
    };

    for (uint32_t i = 0; i < FED_TILE_COUNT; i++) {
        uint32_t slot = i & 3u;
        acc[slot] ^= em->tile_hash[i];
        acc[slot] *= 1099511628211ULL;
    }

    for (int s = 0; s < 4; s++)
        for (int b = 0; b < 8; b++)
            em->root[s*8 + b] = (uint8_t)(acc[s] >> (b*8));

    em->root_valid = 1;

    /* combined_root = first 8 bytes of root[] (legacy compat) */
    uint64_t cr = 0;
    for (int b = 0; b < 8; b++)
        cr |= ((uint64_t)em->root[b]) << (b*8);
    em->combined_root = cr;
}

static inline void em_reset(EarlyMerkle *em)
{
    if (!em) return;
    memset(em, 0, sizeof(*em));
}

/* ══════════════════════════════════════════════════════════════════════
 * SECTION 6 — FEDERATION CONTEXT
 * ══════════════════════════════════════════════════════════════════════ */

typedef struct {
    Delta_ContextAB  dab;        /* disk I/O — core_c types              */
    GateStats        gate;       /* gate pass/ghost/drop counters         */
    BackpressureCtx  bp;         /* flow control                          */
    ShadowSnapshot   ss;         /* double-buffer snapshot                */
    EarlyMerkle      em;         /* V38 tile merkle                       */
    uint64_t         op_count;   /* non-DROP writes processed             */
    char             vault[512];
} FederationCtx;

/* ══════════════════════════════════════════════════════════════════════
 * SECTION 7 — FEDERATION API
 * ══════════════════════════════════════════════════════════════════════ */

static inline int fed_init(FederationCtx *f, const char *vault_path)
{
    if (!f) return -1;
    if (!vault_path) return -1;

    memset(f, 0, sizeof(*f));
    strncpy(f->vault, vault_path, sizeof(f->vault)-1);

    bp_init(&f->bp);
    em_init(&f->em);

    int r = ss_init(&f->ss, vault_path);
    if (r != 0) return r;

    r = storage_delta_ab_open(&f->dab, vault_path);
    if (r != 0) return r;

    return 0;
}

/*
 * fed_write — main write path
 * 1. Gate (iso check, lane audit, ghost window)
 * 2. PASS/GHOST: update EarlyMerkle tile, push bp queue, bump op_count
 * 3. DROP: no-op, return GATE_DROP
 */
static inline GateResult fed_write(FederationCtx *f,
                                    uint32_t       packed,
                                    uint64_t       addr,
                                    uint64_t       data)
{
    if (!f) return GATE_DROP;

    GateResult gr = fed_gate(packed, f->op_count, &f->gate);
    if (gr == GATE_DROP) return GATE_DROP;

    uint32_t lane = (packed >> 20) & 0x3Fu;

    uint8_t buf[16];
    for (int i = 0; i < 8; i++) buf[i]   = (uint8_t)(addr >> (i*8));
    for (int i = 0; i < 8; i++) buf[8+i] = (uint8_t)(data >> (i*8));
    em_update(&f->em, lane, buf, 16);

    bp_push(&f->bp);
    f->op_count++;

    return gr;
}

/*
 * fed_commit — finalize commit window
 * 1. em_reduce → root[32] + root_valid=1
 * 2. ss_commit → swap double-buffer
 * 3. storage_delta_ab_commit → atomic dual Merkle disk flush
 * 4. em_reset → clear tiles for next window
 */
static inline int fed_commit(FederationCtx *f)
{
    if (!f) return -1;

    em_reduce(&f->em);

    int r = ss_commit(&f->ss);
    if (r != 0) return r;

    r = storage_delta_ab_commit(&f->dab);
    if (r != 0) return r;

    em_reset(&f->em);
    return 0;
}

/* Drain up to n items from backpressure queue */
static inline uint32_t fed_drain(FederationCtx *f, uint32_t n)
{
    if (!f) return 0;
    return bp_drain(&f->bp, n);
}

/* Boot recovery — scan both worlds */
static inline Delta_DualRecovery fed_recover(const char *vault_path)
{
    if (!vault_path) {
        Delta_DualRecovery dr = { DELTA_RECOVERY_ERROR, DELTA_RECOVERY_ERROR };
        return dr;
    }
    return storage_delta_ab_recover(vault_path);
}

static inline void fed_close(FederationCtx *f)
{
    if (!f) return;
    storage_delta_ab_close(&f->dab);
    ss_close(&f->ss);
}

#endif /* POGLS_FEDERATION_H */
