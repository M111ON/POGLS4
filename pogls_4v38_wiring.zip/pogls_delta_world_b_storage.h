/*
 * storage/pogls_delta_world_b.h — World B Storage Bridge
 * ═══════════════════════════════════════════════════════
 *
 * Thin forwarding layer: storage/ → core_c/
 * Rule: NEVER define types here — use core_c types exclusively.
 * Only thin inline wrappers permitted (no logic duplication).
 *
 * Architecture (Option A safe):
 *   core_c/   = ground truth (never touch)
 *   storage/  = #include core_c + forward-only inline bridge
 *   federation.h uses storage/ types (which ARE core_c types)
 */

#ifndef STORAGE_POGLS_DELTA_WORLD_B_H
#define STORAGE_POGLS_DELTA_WORLD_B_H

/* ── Ground truth: all types come from here ─────────────────────────── */
#include "../core_c/pogls_delta_world_b.h"

/* core_c/ provides:
 *   Delta_Context, Delta_ContextB, Delta_ContextAB
 *   Delta_DualMerkleRecord, Delta_DualRecovery
 *   Delta_RecoveryResult (CLEAN/TORN/NEW/ERROR)
 *   delta_ab_open(), delta_ab_commit(), delta_ab_recover(), delta_ab_close()
 *   delta_b_open(), delta_b_append(), delta_b_audit(), delta_b_close()
 *   delta_b_merkle_compute()
 *   DELTA_MAGIC = 0x504C4400 ("PLD\0")
 *   DELTA_MAX_PAYLOAD = 224
 *   LANE_COUNT = 4, LANE_B_COUNT = 4, LANE_TOTAL = 8
 */

/* ══════════════════════════════════════════════════════════════════════
 * THIN INLINE BRIDGE — forward-only, no new logic
 * ══════════════════════════════════════════════════════════════════════ */

/*
 * storage_delta_ab_open — thin forward to core_c
 * Creates .pogls/<vault>/world_b/ subdir if needed.
 */
static inline int storage_delta_ab_open(Delta_ContextAB *ctx,
                                         const char      *vault_path)
{
    return delta_ab_open(ctx, vault_path);
}

/*
 * storage_delta_ab_close — thin forward to core_c
 */
static inline int storage_delta_ab_close(Delta_ContextAB *ctx)
{
    return delta_ab_close(ctx);
}

/*
 * storage_delta_ab_recover — thin forward to core_c
 * Returns Delta_DualRecovery {world_a, world_b} each CLEAN/TORN/NEW/ERROR
 */
static inline Delta_DualRecovery storage_delta_ab_recover(const char *vault_path)
{
    return delta_ab_recover(vault_path);
}

/*
 * storage_delta_ab_commit — thin forward to core_c
 * Runs 9-step atomic dual Merkle commit protocol.
 */
static inline int storage_delta_ab_commit(Delta_ContextAB *ctx)
{
    return delta_ab_commit(ctx);
}

#endif /* STORAGE_POGLS_DELTA_WORLD_B_H */
