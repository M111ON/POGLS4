/*
 * pogls_canonical_cpu.h — CPU-only canonical engine (pure C, no CUDA)
 * ══════════════════════════════════════════════════════════════════════
 *
 * Extracted from pogls_canonical.cu — CUDA-free path for G4400 deploy.
 *
 * Rules (same as .cu):
 *   - integer only, no float
 *   - PHI constants identical to pogls_platform.h / pogls_canonical.cu
 *   - fail → snap, never reject  (SOFT mode ready)
 *   - all functions static inline → zero link cost
 *
 * Canonical Projection (same math as GPU path):
 *   a = f(v) → snap to 12-grid  (World A)
 *   b = g(v) → snap to 9-grid   (World B)
 *   x = a²-b², y = 2ab, z = a²+b²  (Pythagorean triple)
 *   output = hash3(x,y,z)
 *
 * Sacred numbers FROZEN: 144, 12, 9, 720, 17, 18, 54, 162, 289
 * ══════════════════════════════════════════════════════════════════════
 */

#ifndef POGLS_CANONICAL_CPU_H
#define POGLS_CANONICAL_CPU_H

#include <stdint.h>

/* ── Constants (must match pogls_canonical.cu exactly) ────────────── */
#define CPU_CAN_PHI_UP    1696631u
#define CPU_CAN_PHI_DOWN  648055u
#define CPU_CAN_PHI_SCALE (1u << 20)
#define CPU_CAN_ANCHOR    144u   /* Fib(12) */
#define CPU_CAN_GRID_A    12u    /* World A snap step */
#define CPU_CAN_GRID_B    9u     /* World B snap step */
#define CPU_CAN_CYCLE     720u   /* temporal closure  */

/* compile-time invariant checks */
typedef char _cpu_can_a[(CPU_CAN_GRID_A * CPU_CAN_GRID_A == CPU_CAN_ANCHOR) ? 1 : -1];
typedef char _cpu_can_b[(CPU_CAN_GRID_B * 16u == CPU_CAN_ANCHOR)            ? 1 : -1];
typedef char _cpu_can_c[(CPU_CAN_CYCLE   % CPU_CAN_ANCHOR == 0)             ? 1 : -1];

/* ── Projection functions ─────────────────────────────────────────── */

/* World A scatter: PHI_UP × v >> 20, mod 144 */
static inline uint32_t cpu_can_f(uint32_t v)
{
    return (uint32_t)(((uint64_t)v * CPU_CAN_PHI_UP >> 20) % CPU_CAN_ANCHOR);
}

/* World B scatter: PHI_DOWN × v >> 20, mod 144 */
static inline uint32_t cpu_can_g(uint32_t v)
{
    return (uint32_t)(((uint64_t)v * CPU_CAN_PHI_DOWN >> 20) % CPU_CAN_ANCHOR);
}

/* Mixing hash — same constants as gpu path */
static inline uint32_t cpu_can_hash3(uint32_t x, uint32_t y, uint32_t z)
{
    uint64_t h = (uint64_t)x * 2654435761u
               ^ (uint64_t)y * 2246822519u
               ^ (uint64_t)z * 3266489917u;
    h ^= h >> 17;
    h *= (uint64_t)CPU_CAN_PHI_DOWN;
    h ^= h >> 31;
    return (uint32_t)(h & 0xFFFFFFFFu);
}

/* ── Main canonicalize (CPU, pure C) ─────────────────────────────── */
/*
 * v_raw → v_clean
 * Snap a to 12-grid, b to 9-grid → Pythagorean embed → hash
 * Always returns a valid v_clean (fail → snap, never reject)
 */
static inline uint32_t cpu_canonicalize(uint32_t v)
{
    uint32_t a = (cpu_can_f(v) / CPU_CAN_GRID_A) * CPU_CAN_GRID_A;
    uint32_t b = (cpu_can_g(v) / CPU_CAN_GRID_B) * CPU_CAN_GRID_B;
    uint32_t x = a*a - b*b;
    uint32_t y = 2u*a*b;
    uint32_t z = a*a + b*b;
    return cpu_can_hash3(x, y, z);
}

/* ── Verify (for testing / SOFT mode audit) ──────────────────────── */
/*
 * Returns 1 if v projects correctly (a on 12-grid, b on 9-grid,
 * Pythagorean identity holds).  Optional a_out/b_out for debug.
 */
static inline int cpu_canonical_verify(uint32_t v,
                                        uint32_t *a_out,
                                        uint32_t *b_out)
{
    uint32_t a = (cpu_can_f(v) / CPU_CAN_GRID_A) * CPU_CAN_GRID_A;
    uint32_t b = (cpu_can_g(v) / CPU_CAN_GRID_B) * CPU_CAN_GRID_B;
    if (a_out) *a_out = a;
    if (b_out) *b_out = b;

    if (a % CPU_CAN_GRID_A != 0) return 0;
    if (b % CPU_CAN_GRID_B != 0) return 0;

    uint64_t x = (uint64_t)a*a - (uint64_t)b*b;
    uint64_t y = 2ULL*a*b;
    uint64_t z = (uint64_t)a*a + (uint64_t)b*b;
    if (x*x + y*y != z*z) return 0;
    return 1;
}

/* ── Soft-mode entry: v_raw → best-effort v_clean ────────────────── */
/*
 * SOFT mode: never rejects.
 * If v_raw already canonical (verify passes) → return as-is.
 * Otherwise → canonicalize and return.
 * Sets *was_raw = 1 if correction was applied (for audit counter).
 */
static inline uint32_t cpu_soft_canonicalize(uint32_t v_raw, int *was_raw)
{
    if (cpu_canonical_verify(v_raw, 0, 0)) {
        if (was_raw) *was_raw = 0;
        return v_raw;
    }
    if (was_raw) *was_raw = 1;
    return cpu_canonicalize(v_raw);
}

#endif /* POGLS_CANONICAL_CPU_H */
